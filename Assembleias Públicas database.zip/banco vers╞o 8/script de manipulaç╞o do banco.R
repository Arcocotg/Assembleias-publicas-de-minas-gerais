
# Começamos configurando o diretório de trababalho com o comando setwd 
setwd("G:/Meu Drive/Nikolas/Faculdade/Pesquisa/banco de dados Eduardo e Thiago/Base de dados/banco segunda fase/vetores")

# Ler a base de dados e colocar ele na variável Banco
Banco <- read.csv2("Base_v8.csv", header=T, sep=',', dec='.', 
                   strip.white = T, na.strings = NA) 

###### Script para a vetorização do Banco  #####

a  <- Banco$ator1
c  <- Banco$cargo1
o  <- Banco$organizacao1
a2 <- Banco$atribuicao1
cabecalho <- Banco[,1:3]

for (i in 2:65) {
  k  <- (i*4)
  a  <- cbind(a ,Banco[,(k)])
  c  <- cbind(c ,Banco[,(k+1)])
  o  <- cbind(o ,Banco[,(k+2)])
  a2 <- cbind(a2,Banco[,(k+3)])
  cabecalho <- rbind(cabecalho,Banco[,1:3])
}

# vetores com cada categoria de variavel
atores      <- matrix(a ,,1)
cargo       <- matrix(c ,,1)
organização <- matrix(o ,,1)
atributo    <- matrix(a2,,1)

# vetores separados por categoria e com entradas unificadas
atoresU      <- unique(atores)
cargoU       <- unique(cargo)
organizaçãoU <- unique(organização)
atributoU    <- unique(atributo)

n <- c(1:nrow(cabecalho))
posicao <- n


# banco verticalmente vetorizado
vetor <- cbind(posicao,cabecalho,atores,cargo,organização,atributo)


#adicionando um indice de posição ao vetores de categoria
atores      <- cbind(n,matrix(a ,,1))
cargo       <- cbind(n,matrix(c ,,1))
organização <- cbind(n,matrix(o ,,1))
atributo    <- cbind(n,matrix(a2,,1))
cabecalho   <- cbind(n,cabecalho)

#Escreve os vetores produzidos

#atores unificados 
write.table(atoresU, file="atoresU.csv", append= F, quote= TRUE,
            sep= ",",eol = "\n", na = "NA", dec = ".",
            row.names = F,col.names = F, 
            qmethod = c("escape", "double"),
            fileEncoding = "")

#cargos unificados
write.table(cargoU, file="cargoU.csv", append= F, quote= TRUE,
            sep= ",",eol = "\n", na = "NA", dec = ".",
            row.names = F,col.names = F, 
            qmethod = c("escape", "double"),
            fileEncoding = "")

#organizações unificados
write.table(organizaçãoU, file="organizaçãoU.csv", append= F, quote= TRUE,
            sep= ",",eol = "\n", na = "NA", dec = ".",
            row.names = F,col.names = F, 
            qmethod = c("escape", "double"),
            fileEncoding = "")

#atores
write.table(atores, file="atores.csv", append= F, quote= TRUE,
            sep= ",",eol = "\n", na = "NA", dec = ".",
            row.names = F,col.names = F, 
            qmethod = c("escape", "double"),
            fileEncoding = "")

#cargos
write.table(cargo, file="cargo.csv", append= F, quote= TRUE,
            sep= ",",eol = "\n", na = "NA", dec = ".",
            row.names = F,col.names = F, 
            qmethod = c("escape", "double"),
            fileEncoding = "")

#organizações
write.table(organização, file="organização.csv", append= F, quote= TRUE,
            sep= ",",eol = "\n", na = "NA", dec = ".",
            row.names = F,col.names = F, 
            qmethod = c("escape", "double"),
            fileEncoding = "")

#Salva o banco vetorizado
write.table(vetor, file="vetor.csv", append= F, quote= TRUE,
            sep= ",",eol = "\n", na = "NA", dec = ".",
            row.names = F,col.names = F, 
            qmethod = c("escape", "double"),
            fileEncoding = "")

# caso queira que o vetor volte ao formato de banco original rodar essas linhas abaixo:

Banco2 <- matrix(NA,nrow(Banco),ncol(Banco))
Banco2[,1:7] <- as.matrix(vetor[1:1344,2:8])
for (k in 2:65) {
  Banco2[,c((k*4),(k*4)+1,(k*4)+2,(k*4)+3)] <- as.matrix(vetor[(1+(1344*(k-1))):(1344*k),5:8])
}
Banco2

###########################Contagem de dados ativos dentro do banco#################################################
dim(atoresU)
dim(cargoU)
dim(organizaçãoU)
#########

###### linha 110 até 266 rodar para relatório de dados ativos


cont <- 0

for (i in 1:87360) {
  if(atores[i,2]!="*nulo"){
    cont <- cont+1
  }
}
natores <- cont

cont <- 0

for (i in 1:87360) {
  if(cargo[i,2]!="*nulo"){
    cont <- cont+1
  }
}
ncargo <- cont


cont <- 0

for (i in 1:87360) {
  if(organização[i,2]!="*nulo"){
    cont <- cont+1
  }
}
norganização <- cont

# numero de ativos
natores
ncargo
norganização


############# Sem atores

cont <- 0

for (i in 1:87360) {
  if((atores[i,2]!="*nulo")&&(cargo[i,2]=="*nulo")&&(organização[i,2]=="*nulo")){
    cont <- cont+1
  }
}
atorSamb <- cont

cont <- 0

for (i in 1:87360) {
  if((atores[i,2]!="*nulo")&&(cargo[i,2]=="*nulo")){
    cont <- cont+1
  }
}
atorScarg <- cont

cont <- 0

for (i in 1:87360) {
  if((atores[i,2]!="*nulo")&&(organização[i,2]=="*nulo")){
    cont <- cont+1
  }
}
atorSorg <- cont


atorSamb
atorScarg
atorSorg

############# Sem cargo

cont <- 0

for (i in 1:87360) {
  if((cargo[i,2]!="*nulo")&&(atores[i,2]=="*nulo")&&(organização[i,2]=="*nulo")){
    cont <- cont+1
  }
}
cargSamb <- cont

cont <- 0

for (i in 1:87360) {
  if((cargo[i,2]!="*nulo")&&(atores[i,2]=="*nulo")){
    cont <- cont+1
  }
}
cargSator <- cont

cont <- 0

for (i in 1:87360) {
  if((cargo[i,2]!="*nulo")&&(organização[i,2]=="*nulo")){
    cont <- cont+1
  }
}
CargSorg <- cont


cargSamb
cargSator
CargSorg

############# Sem organização

cont <- 0

for (i in 1:87360) {
  if((organização[i,2]!="*nulo")&&(atores[i,2]=="*nulo")&&(cargo[i,2]=="*nulo")){
    cont <- cont+1
  }
}
orgSamb <- cont

cont <- 0

for (i in 1:87360) {
  if((organização[i,2]!="*nulo")&&(atores[i,2]=="*nulo")){
    cont <- cont+1
  }
}
orgSator <- cont

cont <- 0

for (i in 1:87360) {
  if((organização[i,2]!="*nulo")&&(cargo[i,2]=="*nulo")){
    cont <- cont+1
  }
}
orgScarg <- cont


##########################
atorSamb
atorScarg
atorSorg
#
cargSamb
cargSator
CargSorg
#
orgSamb
orgSator
orgScarg

DadosDiferentes <- c(nrow(atoresU),nrow(cargoU),nrow(organizaçãoU),sum(nrow(atoresU),nrow(cargoU),nrow(organizaçãoU)))
DadosAtivos <- c(natores,ncargo,norganização,sum(natores,ncargo,norganização))
AtorSem <- c(atorSamb,atorScarg,atorSorg,(atorScarg+atorSorg-atorSamb))
CargoSem <- c(cargSator,cargSamb,CargSorg,(cargSator+CargSorg-cargSamb))
OrgSem <- c(orgSator,orgScarg,orgSamb,(orgSator+orgScarg-orgSamb))
sumario <- c("atores","cargo", "organização","total")

tabela <- t(data.frame(sumario,DadosDiferentes,DadosAtivos,AtorSem,CargoSem,OrgSem))
View(tabela)
################################################################

## proposta de abordagem para filtrar analise da rede 
#o script abaixo tem como objetivo utilizar algum determinado atributo para regular a sensibilidade do banco.
vetor2 <- vetor
#ao chamar os atibuitos unicos vermos os tipos de atributos que temos no banco
atributoU
#ao escolher um deles exemplo: pm_mg. Podemos subistitui-lo na coluna das organizações com o seguintes linhas:
filtro <- "pm_mg"

for (l in 1:30) {
  if(vetor2$atributo[l]==filtro){
    vetor2$organização[l] <- filtro
  }
}

#Salva o banco vetorizado
write.table(vetorfiltrado, file="vetor2.csv", append= F, quote= TRUE,
            sep= ",",eol = "\n", na = "NA", dec = ".",
            row.names = F,col.names = F, 
            qmethod = c("escape", "double"),
            fileEncoding = "")


